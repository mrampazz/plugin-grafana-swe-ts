export class ConfigCtrl {
  static templateUrl: string;
  $location: any;

  constructor($location) {
    this.$location = $location;
  }

}

ConfigCtrl.templateUrl = "components/config.html";
