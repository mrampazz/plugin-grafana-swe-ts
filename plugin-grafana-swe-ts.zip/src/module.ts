import { ConfigCtrl} from "./components/config";

export {
  ConfigCtrl,
};
